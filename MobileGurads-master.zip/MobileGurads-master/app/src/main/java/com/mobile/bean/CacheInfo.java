package com.mobile.bean;

import android.graphics.drawable.Drawable;

/**
 * Created by xiaofei on 2017/3/18.
 *
 */

public class CacheInfo {
    public String apkName;
    public Drawable icon;
    public String packageName;
    public long cacheSize;
}
