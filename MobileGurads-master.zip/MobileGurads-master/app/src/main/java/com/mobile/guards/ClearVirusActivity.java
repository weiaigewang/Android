package com.mobile.guards;

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.mobile.bean.VirusBean;
import com.mobile.engine.VirusDao;
import com.mobile.utils.Md5Encrypt;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ClearVirusActivity extends AppCompatActivity {

    private ProgressBar pb_scan;
    private TextView tv_apkname,tv_scanning;
    private ImageView iv_img_scan;
    private LinearLayout layout;

    //记录扫描应用数
    private int index;
    private RotateAnimation mRotate;
    //记录病毒的集合
    List<VirusBean> listVirusBean;

    private static final int SCANNING = 100;
    private static final int SCAN_FINISH = 101;

    private Handler mHandler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);

            switch (msg.what){
                case SCANNING:
                    //更新名字
                    VirusBean bean = (VirusBean) msg.obj;
                    tv_apkname.setText(bean.apkName);

                    //在线性布局中添加textview
                    TextView tv = new TextView(getApplicationContext());
                    tv.setTextSize(15);
                    if(bean.isVirus){
                        //病毒
                        tv.setTextColor(Color.RED);
                        tv.setText("发现病毒"+bean.apkName);
                    }else{
                        //不是病毒
                        tv_apkname.setTextColor(Color.BLACK);
                        tv.setText("扫描安全"+bean.apkName);
                    }
                    //加入布局，从头部加入
                    layout.addView(tv,0);
                    break;
                case SCAN_FINISH:
                     tv_scanning.setText("扫描完成");
                     iv_img_scan.clearAnimation();
                    //告知用户卸载病毒应用
                    unInstallVirus();
                    break;
            }
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clear_virus);
        initView();
        initData();
        initAnimation();
        initDB();
        findVirus();

    }


    private void initDB() {
        initAssetsDB("virus.db");
    }

    /***
     * 初始化assets文件中的DB,写入files文件中
     * @param dbName
     */
    private void initAssetsDB(String dbName) {
        /****
         * 1在files文件加下创建同名数据库文件
         */
        File files = getFilesDir();
        File file = new File(files,dbName);
        //文件已经存在
        if(file.exists()){
            return;
        }
            InputStream is = null;
            FileOutputStream fos = null;
            //2 用输入六读取assets文件下的数据库内容
            try {
                is = getAssets().open(dbName);
                //3 读取文件写入指定的文件里
                fos = new FileOutputStream(file);
                //4 读取文件
                byte[] bt = new byte[1024];
                int tmp = -1;
                while ((tmp = is.read(bt)) != -1){
                   fos.write(bt,0,tmp);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }finally {
                if(is != null && fos != null){
                    try {
                        is.close();
                        fos.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

    }

    /***
     *
     */
    private void initView() {
        pb_scan = (ProgressBar) findViewById(R.id.progress_scanning_bar);
        //应用名称
        tv_apkname = (TextView) findViewById(R.id.tv_add_scanned);
        tv_scanning = (TextView) findViewById(R.id.tv_scanning);
        iv_img_scan = (ImageView) findViewById(R.id.iv_scanning);

        layout = (LinearLayout) findViewById(R.id.linear_layout_add_text);
    }

    /*****
     *
     */
    private void initData() {

    }

    /***
     * 为正在扫描的图片添加动画效果
     */
    private void initAnimation() {
        /****
         * 添加动画旋转
         * 从fromDegress:0度到toDegress:360度
         * pivotXType:依赖于自身的正中心位置，pivotXValue:依赖于x轴
         * pivotYType:依赖于自身的正中心位置，pivotYValue:依赖于Y轴
         *
         */
        mRotate = new RotateAnimation(0,360,
                Animation.RELATIVE_TO_SELF,0.5f,
                Animation.RELATIVE_TO_SELF,0.5f);
        //转一圈一秒钟
        mRotate.setDuration(1000);
        //一直旋转
        //mRotate.setRepeatMode(RotateAnimation.INFINITE);
        //设置最大值也可以一直旋转
        mRotate.setRepeatCount(RotateAnimation.INFINITE);
        //动画结束之后的状态
        mRotate.setFillAfter(true);
        iv_img_scan.startAnimation(mRotate);
    }

    /*****
     * 查找病毒
     * 拿到手机上所有应用的包签名，
     * 然后加密成md5码去与病毒库中的md5码做比较
     */
    private void findVirus() {
        /****
         * 数据库耗时操作放在子线程中间
         */
        new Thread(){

            @Override
            public void run() {
                super.run();
                /****
                 * 耗时操作，查找病毒库中的病毒md5码
                 */
                List<String> listVirus = VirusDao.getVirusList();
                //1获取包管理器
                PackageManager manager = getPackageManager();
                /***
                 * 2 获取已安装应用的签名PackageManager.GET_SIGNATURES
                 *          卸载残留 PackageManager.GET_UNINSTALLED_PACKAGES
                 */
                List<PackageInfo> listpacInfo = manager.getInstalledPackages(
                        PackageManager.GET_SIGNATURES + PackageManager.GET_UNINSTALLED_PACKAGES);
                //创建记录病毒的集合
                listVirusBean = new ArrayList<VirusBean>();

                //记录所有应用的集合
                List<VirusBean> scanList = new ArrayList<VirusBean>();
                //设置进度条最大值
                pb_scan.setMax(listpacInfo.size());

                //3拿每一个应用的签名
                for(PackageInfo packageinfo:listpacInfo){

                    //获取签名文件数组
                    Signature[] signatures = packageinfo.signatures;
                    Signature signature = signatures[0];
                    String signature_tostring = signature.toCharsString();

                    //加密签名得到md5码与数据库当中的md5码进行对比
                    String sig32_md5 = Md5Encrypt.encoder(signature_tostring,packageinfo.packageName);


                    //获取指定的病毒文件签名
                    //String md5 = Md5Encrypt.getFileMd5("E:/Seting/app-release.apk");
                    //System.out.println("要检测的病毒app签名md5码："+md5.toString());
                    //4 查找病毒
                    if(listVirus.contains(sig32_md5)){
                        //5 记录病毒
                        VirusBean bean= new VirusBean();
                        bean.isVirus = true;
                        listVirusBean.add(bean);
                        //6维护对象包名以及应用
                        bean.packageName = packageinfo.packageName;
                        bean.apkName = packageinfo.applicationInfo.loadLabel(manager).toString();
                        scanList.add(bean);


                        try {
                            //进度条递增没有规律
                            Thread.sleep(50 + new Random().nextInt(100));
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }

                        //7扫描过程，增加进度条
                        index++;
                        pb_scan.setProgress(index);

                        //8 更新UI,往子线程中发送消息
                        Message message = Message.obtain();
                        message.what = SCANNING;
                        message.obj = bean;
                        mHandler.sendMessage(message);
                    }else{

                        VirusBean bean2 = new VirusBean();
                        bean2.isVirus = false;
                        //6维护对象包名以及应用
                        bean2.packageName = packageinfo.packageName;
                        bean2.apkName = packageinfo.applicationInfo.loadLabel(manager).toString();
                        scanList.add(bean2);

                        try {
                            //进度条递增没有规律
                            Thread.sleep(50 + new Random().nextInt(100));
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        //7扫描过程，增加进度条
                        index++;
                        pb_scan.setProgress(index);
                        //8 更新UI,往子线程中发送消息
                        Message message = Message.obtain();
                        message.what = SCANNING;
                        message.obj = bean2;
                        mHandler.sendMessage(message);
                    }
                    //6维护对象包名以及应用
                    //bean.packageName = packageinfo.packageName;
                    //bean.apkName = packageinfo.applicationInfo.loadLabel(manager).toString();
                    //scanList.add(bean);


                }
                Message message = Message.obtain();
                message.what = SCAN_FINISH;
                mHandler.sendMessage(message);
            }
        }.start();

    }

    /****
     * 卸载病毒应用
     */
    private void unInstallVirus() {
        for(VirusBean bean :listVirusBean){
            String packageName = bean.packageName;
            //卸载源码
            Intent intent = new Intent("android.intent.action.DELETE");
            intent.addCategory("android.intent.category.DEFAULT");
            intent.setData(Uri.parse("package:"+packageName));
            startActivity(intent);
        }
    }

}
