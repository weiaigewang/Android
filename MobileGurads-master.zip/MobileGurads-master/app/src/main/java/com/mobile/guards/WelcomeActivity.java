package com.mobile.guards;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.animation.AlphaAnimation;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.mobile.utils.StreamUtil;
import com.mobile.utils.ToastUtil;

import net.youmi.android.AdManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class WelcomeActivity extends Activity {

    private TextView versionName;
    //成员变量member，
    private int mLocalVersion;
    private String mVersionDescription;
    private String mDownloadUrl;
    private RelativeLayout rl_root;
    /****启动系统安装apk的action*****/
    //private static final String action = "android.intent.action.VIEW";
    //private static final String action2 = "Intent.ACTION_VIEW";
    //private static final String category = "android.intent.category.DEFAULT";
    //private static final String archive = "application/vnd.android.package-archive";


    protected static final String tag = "WelcomeActivity";
    //message状态码
    private static final int UPDATE_VERSION = 100;
    private static final int ENTER_HOME= 101;
    private static final int URL_LOCATION_ERROR = 102;
    private static final int IO_ERROR = 103;
    private static final int JSON_ERROR = 104;

    private Handler mHandler = new Handler(){
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what){
                case UPDATE_VERSION:
                    //弹出对话框提示用户更新
                    showUpdateInfo();
                    break;
                case ENTER_HOME://将进入主界面
                    enterTheMain();
                    break;
                case URL_LOCATION_ERROR:
                    ToastUtil.show(WelcomeActivity.this,"URL异常");
                    enterTheMain();
                    break;
                case IO_ERROR:
                    ToastUtil.show(WelcomeActivity.this,"读取异常");
                    enterTheMain();
                    break;
                case JSON_ERROR:
                    ToastUtil.show(WelcomeActivity.this,"json解析异常");
                    enterTheMain();
                    break;

            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //int i = 10 / 0;

        initView();
        initData();
        initAlphaAnimation();

        //有米广告
        AdManager.getInstance(WelcomeActivity.this)
                .init("f86b4a7206cbc9a8", "64c5bf04422e4bf1",true);
    }

    /******
     * 初始化UI  alt+shift+j
     */
    private void initView() {
        versionName = (TextView) findViewById(R.id.tv_version_name);
        rl_root = (RelativeLayout) findViewById(R.id.activity_main);
    }

    /***初始化数据****/
    private void initData() {
        /****
         * 1 设置应用版本号
         */
        String name = getVersionName();
        versionName.setText("版本号:"+name);
        /****
         * 2检测用户版本跟新（本地版本与服务器版本比对），提示用户下载
         * mLocalVersion(本地版本号)：源码编写代码的时候成员变量member一般首字母为
         * m开头后面一个字母大写，m代表member的意思
         */
        mLocalVersion = getLocalVersionCode();
        /******
         * 获取服务端版本号（客户端请求，服务端接收（json,xml））
         * http://www.xxxxxxx.com/update.json?key=value
         * 服务器请求返回码：200；请求成功将以流的形式读取数据
         */
        //json内容：更新版本的版本名称，新版本的描述,服务器版本号，新的apk下载地址
        findVersion();
    }

    /******
     * @return
     * 获取版本名称：版本名称放在清单文件中
     */
    private String getVersionName() {
        //1 获取保资源管理对象
        PackageManager packageManger = getPackageManager();
        /***
         * 2 从packManger对象中获取报名的基本信息（即 版本名称 版本号）
         * packageName:报资源管理器对象
         * flages:0 代表获取基本信息
         */
        try {
            PackageInfo packageInfo = packageManger.getPackageInfo(this.getPackageName(),0);
            return packageInfo.versionName;
            /***
             * 当前应用包名找不到异常
             */
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }

    /******
     * 获取本地版本号:非0代表成功
     * @return
     */
    private int getLocalVersionCode() {

        PackageManager packageManger = getPackageManager();
        try {
            PackageInfo packageInfo = packageManger.getPackageInfo(this.getPackageName(),0);
            return packageInfo.versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return  0;
    }

    /******** 检测版本号*/
    private void findVersion() {
//        new Thread(){
//            @Override
//            public void run() {
//                super.run();
//            }
//        }.start();
        //开启线程
        new Thread(new Runnable() {
            @Override
            public void run() {

               //Message message = new Message();
               Message msg = Message.obtain();
               long startTime = System.currentTimeMillis();
              //发送请求
                try {
                    /*****1 封装一个url地址
                     * 1 不能写成"http://localhost:8080/update.json"因为手机上没有TomCat服务器
                     * 2 http://10.33.252.189:8080/update.json这种写法不好，电脑端ip会随时变化
                     * 3 应该申请一个域名，上现阶段才用
                     * 4 http://10.0.0.2:8080/update.json  这种写法仅限于模拟器访问电脑端tomcat
                     *   这是谷歌提供的一种方法
                     */
                    URL url = new URL("http://192.168.42.106:8080/update.json");
                    //2 开启一个连接
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    /***
                     *  3 设置常见请求参数，即设置请求头
                     */
                    //请求超时2秒
                    connection.setConnectTimeout(2000);
                    //读取超时
                    connection.getReadTimeout();
                    //请求方式：默认get请求connection.getRequestMethod("POST");
                    connection.getRequestMethod();
                    //获取响应码
                    if(connection.getResponseCode()==200){
                        //以流形式读取文件
                        InputStream is = connection.getInputStream();
                        //将流转换成字符串进行读取（用工具类进行封装）
                        String downJson = StreamUtil.streamToString(is);
                        //一般来说tag都是当前类名
                        Log.i(tag,downJson);
                        //Json解析
                        JSONObject jo =new JSONObject(downJson);
                        String versionName = jo.getString("versionName");
                        String versionCode = jo.getString("versionCode");
                        mVersionDescription = jo.getString("versionDescription");
                        mDownloadUrl = jo.getString("downloadUrl");

                        Log.i(tag,versionName);
                        Log.i(tag,versionCode);
                        Log.i(tag,mVersionDescription);
                        Log.i(tag,mDownloadUrl);

                        //对比版本号，提示用户更新或者进入用户主界面
                        if(mLocalVersion<Integer.parseInt(versionCode)){
                            //提示用户更新,弹出框(UI）不能跟新UI线程，消息机制
                            msg.what = UPDATE_VERSION;
                        }else{
                            //进入应用程序户界面
                            msg.what = ENTER_HOME;
                        }
                    }
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                    msg.what = URL_LOCATION_ERROR;
                } catch (IOException e) {
                    e.printStackTrace();
                    msg.what = IO_ERROR;
                } catch (JSONException e) {
                    e.printStackTrace();
                    msg.what = JSON_ERROR;
                }finally {
                    //请求网络4秒过后不再请求
                    //请求少于4秒
                    long endTime = System.currentTimeMillis();
                    if((endTime - startTime)<4000){
                        try {
                            Thread.sleep(4000-(endTime-startTime));
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                    mHandler.sendMessage(msg);
                }
            }
        }).start();
    }

    /***进入主页****/
    private void enterTheMain() {
        Intent i = new Intent(this,HomeActivity.class);
        startActivity(i);
        finish();
    }

    /****提示更新APP对话框*********/
    private void showUpdateInfo() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setIcon(R.drawable.dialog_prompt);
        builder.setTitle("版本更新提示");
        builder.setMessage(mVersionDescription);

        builder.setPositiveButton("立即更新", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                //下载APK(多线程断点续传)
                downloadAPP();
            }
        });
        builder.setNegativeButton("暂不更新", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                //取消对话框
                enterTheMain();
            }
        });
        builder.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialogInterface) {
                enterTheMain();
                dialogInterface.dismiss();
            }
        });
        builder.show();
    }

    /*******下载APP************/
    private void downloadAPP() {
        /***SD卡已挂载****/
        if(Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)){
            /********获取SD卡路径***********/
            String path = Environment.getExternalStorageDirectory().getAbsolutePath()+File.separator+"gruads.apk";
            /***发送请求，获取APK,放置在指定路径****/
            HttpUtils utils = new HttpUtils();
            /***
             * mDownloadUrl,
             * target,放置位置
             * callback
             */
            utils.download(mDownloadUrl, path, new RequestCallBack<File>() {
                //成功
                @Override
                public void onSuccess(ResponseInfo<File> responseInfo) {
                    //下载成功，放置在文件中的apk
                    Log.i(tag,"下载成功！！！！");
                    File file =  responseInfo.result;
                    //String filePath = file.getAbsolutePath();
                    //Log.i(tag,file.getAbsolutePath());
                    //提示用户安装
                    installAPP(file);

                }
                //失败
                @Override
                public void onFailure(HttpException e, String s) {
                    Log.i(tag,"下载失败！！！！");
                }
                //刚开始下载
                @Override
                public void onStart() {
                    super.onStart();
                    Log.i(tag,"下载开始！！！！");
                }

                /***
                 *
                 * @param total  下载的总大小
                 * @param current 当前下载位置
                 * @param isUploading  是否下载
                 */
                @Override
                public void onLoading(long total, long current, boolean isUploading) {

                    Log.i(tag,"正在下载！！！！");
                    Log.i(tag, String.valueOf(total));
                    Log.i(tag, String.valueOf(current));
                    Log.i(tag, String.valueOf(isUploading));

                    super.onLoading(total, current, isUploading);
                }
            });

        }
        //下载链接地址，放至APk的写入路径
    }

    /***
     * 安装APP
     * @param file 安装的文件
     */
    protected void installAPP(File file) {
        //安装APK的界面就是一个系统界面（Activity），首先找到系统安装APK进入的路口
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.addCategory("android.intent.category.DEFAULT");

        intent.setType("application/vnd.android.package-archive");
        intent.setData(Uri.fromFile(file));
        //设置安装类型

        //intent.setDataAndType(Uri.fromFile(file),"application/vnd.android.package-archive");
        //startActivity(intent);
        startActivityForResult(intent, 0);
    }

    //开启一个activity后,返回结果调用的方法
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        enterTheMain();
    }

    /*****进入动画启动主界面*******/

    private void initAlphaAnimation() {
        /****从透明到不透明**/
        AlphaAnimation alpha = new AlphaAnimation(0,1);
        alpha.setDuration(3000);
        rl_root.startAnimation(alpha);
    }

}
