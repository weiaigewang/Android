package com.mobile.guards;

import android.os.Bundle;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.mobile.bean.AppInfo;
import com.mobile.engine.AppInfoProvider;

import java.util.List;

public class ListAppActivity extends AppCompatActivity {

    private LinearLayout layout;
    private ListView lvListApp;
    private List<AppInfo> mlistAppInfo;
    private AppListAdapter mAdapter;


    public static final int SCANNING_APP = 100;

    private android.os.Handler mHandler = new android.os.Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);

            mAdapter = new AppListAdapter();
            lvListApp.setAdapter(mAdapter);

            switch (msg.what){
                case SCANNING_APP:

                    break;
            }
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_app);

        initView();
        initData();
    }

    private void initView() {
        layout = (LinearLayout) findViewById(R.id.ll_list_app);
        lvListApp = (ListView) findViewById(R.id.id_list_app);
    }

    private void initData() {
        new Thread() {
            @Override
            public void run() {
                super.run();
                mlistAppInfo = AppInfoProvider.getAppListInfo(getApplicationContext());
                mHandler.sendEmptyMessage(0);
            }
        }.start();

    }

    class AppListAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return mlistAppInfo.size();
        }

        @Override
        public Object getItem(int position) {
            return mlistAppInfo.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ViewHolder holder = null;
            if(convertView == null){
                convertView = View.inflate(getApplicationContext(),R.layout.list_app_item,null);
                holder = new ViewHolder();
                holder.tv_name = (TextView) convertView.findViewById(R.id.tv_apk_name);
                holder.tv_path = (TextView) convertView.findViewById(R.id.tv_apk_pac_name);
                holder.iv_icon = (ImageView) convertView.findViewById(R.id.iv_apk_icon);
                convertView.setTag(holder);
            }else{
                holder = (ViewHolder) convertView.getTag();
            }
            holder.tv_name.setText(mlistAppInfo.get(position).appLabel);
            holder.iv_icon.setBackgroundDrawable(mlistAppInfo.get(position).appIcon);

            if(mlistAppInfo.get(position).isSdCard){
                holder.tv_path.setText("sd卡应用");
            }else{
                holder.tv_path.setText("手机应用");
            }

            return convertView;
        }
    }

    static class ViewHolder{
        ImageView iv_icon;
        TextView tv_name;
        TextView tv_path;
    }

    static class ViewTitleHolder{
        TextView tv_title;
    }
}
