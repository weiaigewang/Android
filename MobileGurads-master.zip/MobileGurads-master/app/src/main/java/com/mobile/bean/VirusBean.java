package com.mobile.bean;

/**
 * Created by xiaofei on 2017/3/13.
 *
 */

public class VirusBean {
    public boolean isVirus;
    public String packageName;
    public String apkName;
}
