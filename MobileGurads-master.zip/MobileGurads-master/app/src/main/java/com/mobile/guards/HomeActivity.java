package com.mobile.guards;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;

import net.youmi.android.banner.AdSize;
import net.youmi.android.banner.AdView;

import java.util.Random;

public class HomeActivity extends AppCompatActivity {

    private ImageView iv_rotate;
    private RotateAnimation mRotate;
    private AtyHomeBtnItem btn_scan;
    private AtyHomeBtnItem btn_clear_cache;
    private AtyHomeBtnItem btn_mannage_process;
    private AtyHomeBtnItem btnAllApp;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        initView();
        initData();
        initAnimation();

        /*****
         * 集成有米广告
         */
        // 实例化广告条
        AdView adView = new AdView(this, AdSize.FIT_SCREEN);
        // 获取要嵌入广告条的布局
        LinearLayout adLayout=(LinearLayout)findViewById(R.id.adLayout);
        // 将广告条加入到布局中
        adLayout.addView(adView);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

    }

    private void initView() {

        iv_rotate = (ImageView) findViewById(R.id.iv_rotateing);
        btn_scan = (AtyHomeBtnItem) findViewById(R.id.btn_check_virus);
        btn_clear_cache = (AtyHomeBtnItem) findViewById(R.id.btn_item_clear);
        btn_mannage_process = (AtyHomeBtnItem) findViewById(R.id.btn_item_manage_process);
        btnAllApp = (AtyHomeBtnItem) findViewById(R.id.btn_all_app);
    }

    private void initData() {

        //安全扫描
        btn_scan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this, ClearVirusActivity.class));
            }
        });
        //清理缓存
        btn_clear_cache.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this, ClearCacheActivity.class));
            }
        });
        //进程管理
        btn_mannage_process.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this, ManageProcessActivity.class));
            }
        });
        //应用列表
        btnAllApp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this,ListAppActivity.class));
            }
        });
    }


    private void initAnimation() {
        /****
         * 添加动画旋转
         * 从fromDegress:0度到toDegress:360度
         * pivotXType:依赖于自身的正中心位置，pivotXValue:依赖于x轴
         * pivotYType:依赖于自身的正中心位置，pivotYValue:依赖于Y轴
         *
         */
        mRotate = new RotateAnimation(0, 360,
                Animation.RELATIVE_TO_SELF, 0.5f,
                Animation.RELATIVE_TO_SELF, 0.5f);
        //转一圈一秒钟
        mRotate.setDuration(1000);
        //一直旋转
        //mRotate.setRepeatMode(RotateAnimation.INFINITE);
        //设置最大值也可以一直旋转
        mRotate.setRepeatCount(RotateAnimation.INFINITE);
        //开启动画
        try {
            //进度条递增没有规律
            Thread.sleep(20 + new Random().nextInt(30));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        iv_rotate.startAnimation(mRotate);
    }


}
