package com.mobile.engine;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;

import com.mobile.bean.AppInfo;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * Created by xiaofei on 2017/4/2.
 */

public class AppInfoProvider {

    public static List<AppInfo> getAppListInfo(Context context){

        PackageManager manager = context.getPackageManager();
        //【2】获取安装在手机上应用相关信息的集合
        List<PackageInfo> packageInfoList = manager.getInstalledPackages(0);
        List<AppInfo> appInfoList = new ArrayList<AppInfo>();
        //3,循环遍历应用信息的集合
        for (PackageInfo packageInfo : packageInfoList) {
            AppInfo appInfo = new AppInfo();
            //4,获取应用的包名
            appInfo.appPackageName = packageInfo.packageName;
            //5,应用名称
            ApplicationInfo applicationInfo = packageInfo.applicationInfo;
            appInfo.appLabel = applicationInfo.loadLabel(manager).toString();
            //6,获取图标
            appInfo.appIcon = applicationInfo.loadIcon(manager);
            //7,判断是否为系统应用(每一个手机上的应用对应的flag都不一致)
            if((applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM)==ApplicationInfo.FLAG_SYSTEM){
                //系统应用
                appInfo.isSystem = true;
            }else{
                //非系统应用
                appInfo.isSystem = false;
            }
            //8,是否为sd卡中安装应用
            if((applicationInfo.flags & ApplicationInfo.FLAG_EXTERNAL_STORAGE)==ApplicationInfo.FLAG_EXTERNAL_STORAGE){
                //系统应用
                appInfo.isSdCard = true;
            }else{
                //非系统应用
                appInfo.isSdCard = false;
            }
            appInfoList.add(appInfo);
        }
        return appInfoList;
    }
}
