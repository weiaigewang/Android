package com.mobile.guards;

import android.content.Intent;
import android.content.pm.IPackageDataObserver;
import android.content.pm.IPackageStatsObserver;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageStats;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.RemoteException;
import android.support.v7.app.AppCompatActivity;
import android.text.format.Formatter;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.mobile.bean.CacheInfo;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

public class ClearCacheActivity extends AppCompatActivity {

    private TextView tv_progress;
    private TextView tv_packageName;
    private ProgressBar pb_bar;

    private LinearLayout ll_addCacheItem;

    private static final int UPDATE_LIST_VIEW = 100;
    private static final int SCANNING_CACHE = 101;
    private static final int SCANNING_FINISH = 102;

    private static final int CLEAR_ALL_CACHE = 104;

    private PackageManager manager;

    private Handler mHandler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what){
                case UPDATE_LIST_VIEW:
                    //添加有缓存目录
                    View view = View.inflate(getApplicationContext(),R.layout.listview_item_cache,null);

                    ImageView iv_icon = (ImageView) view.findViewById(R.id.id_iv_apk_img);
                    ImageView iv_choice = (ImageView) view.findViewById(R.id.id_iv_choice);
                    TextView tv_apkName = (TextView) view.findViewById(R.id.id_tv_package_name);
                    TextView tv_apkCache = (TextView) view.findViewById(R.id.id_tv_app_cache);

                    final CacheInfo info = (CacheInfo) msg.obj;
                    //iv_icon.setImageDrawable(info.icon);
                    iv_icon.setBackgroundDrawable(info.icon);
                    tv_apkName.setText(info.apkName);
                    tv_apkCache.setText(Formatter.formatFileSize(getApplicationContext(),
                            info.cacheSize));

                    //mItem,0  view对象，索引值
                    ll_addCacheItem.addView(view,0);

                    iv_choice.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            //清除单个选中应用的缓存内容(PackageMananger)

                            //源码开发课程(源码(handler机制,AsyncTask(异步请求,手机启动流程)源码))
                            //通过查看系统日志,获取开启清理缓存activity中action和data
                            Intent intent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS");
                            intent.setData(Uri.parse("package:"+info.packageName));
                            startActivity(intent);
                        }
                    });
                    //CacheInfo cache = new CacheInfo();
                    //cache.cacheSize += info.cacheSize;
                    //long cache_size = cache.cacheSize;

                    tv_progress.setText(Formatter.formatFileSize(getApplicationContext(),info.cacheSize));
                    break;
                case SCANNING_CACHE:
                    tv_packageName.setText((String)msg.obj);
                    break;
                case SCANNING_FINISH:
                    tv_packageName.setText("扫描完成");
                    tv_progress.setText("一键清理");
                    tv_progress.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            //1.获取指定类的字节码文件
                            try {
                                Class<?> clazz = Class.forName("android.content.pm.PackageManager");
                                //2.获取调用方法对象
                                Method method = clazz.getMethod("freeStorageAndNotify", long.class,IPackageDataObserver.class);
                                //3.获取对象调用方法
                                method.invoke(manager, Long.MAX_VALUE,new IPackageDataObserver.Stub() {
                                    @Override
                                    public void onRemoveCompleted(String packageName, boolean succeeded)
                                            throws RemoteException {
                                        //清除缓存完成后调用的方法(考虑权限)
                                        Message msg = Message.obtain();
                                        msg.what = CLEAR_ALL_CACHE;
                                        mHandler.sendMessage(msg);
                                    }
                                });
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
                    break;
                case CLEAR_ALL_CACHE:
                    ll_addCacheItem.removeAllViews();
                    break;
            }
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clear_cache);

        initView();
        initData();
    }

    private void initView() {
        //圆圈内显示缓存总数
        tv_progress = (TextView) findViewById(R.id.id_tv_show_progress);
        //进度条下显示遍历的每一个包名
        tv_packageName = (TextView) findViewById(R.id.id_tv_apk_package_name);
        //progressbar进度
        pb_bar = (ProgressBar) findViewById(R.id.id_pb_progress);
        //用来添加缓存条目的LinearLayout
        ll_addCacheItem = (LinearLayout) findViewById(R.id.id_ll_addcache_item);

        //一键清理
//        tv_progress.setOnClickListener(new View.OnClickListener() {
//
//            @Override
//            public void onClick(View v) {
//
//                //以下代码如果要执行成功则需要系统应用才可以去使用的权限
//                // android.permission.DELETE_CACHE_FILES
//                CacheInfo cacheInfo = new CacheInfo();
//                try {
//                    Class<?> clazz = Class.forName("android.content.pm.PackageManager");
//                    //2.获取调用方法对象
//                    Method method = clazz.getMethod("deleteApplicationCacheFiles", String.class,IPackageDataObserver.class);
//                    //3.获取对象调用方法
//                    method.invoke(manager, cacheInfo.packageName,new IPackageDataObserver.Stub() {
//                        @Override
//                        public void onRemoveCompleted(String packageName, boolean succeeded)
//                                throws RemoteException {
//                            //删除此应用缓存后,调用的方法,子线程中
//                            Log.i("ClearCacheActivity", "清理完成");
//
//                            Message message =Message.obtain();
//                            message.what = CLEAR_ALL_CACHE;
//                            mHandler.sendMessage(message);
//                        }
//                    });
//                } catch (Exception e) {
//                    // TODO Auto-generated catch block
//                    e.printStackTrace();
//                }
//            }
//        });
    }

    /****
     *遍历手机中的应用，获取缓存
     */
    private void initData() {

        new Thread(){
            @Override
            public void run() {
                super.run();

                try {
                    tv_progress.setText("垃圾清理");
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                //1 获取包资源管理
                manager = getPackageManager() ;
                //2 获取已安装的所有应用
                List<PackageInfo> listInstalled =  manager.getInstalledPackages(0);
                //3 设置进度条最大值
                pb_bar.setMax(listInstalled.size());

                Log.i("总条目：",String.valueOf(listInstalled.size()));
                int index=0;
                //4 遍历每一个应用(应用图标，名称，缓存大小）
                for(PackageInfo packageinfo : listInstalled){
                    String packageName = packageinfo.packageName;


                    index++;
                    getPackageCache(packageName);
                    Log.i("包名packageName = = ：",packageName);


                    //每获得一个包名就循环检查一次
                    String name = null;
                    try {
                        name = manager.getApplicationInfo(packageName, 0)
                                .loadLabel(manager).toString();
                    } catch (PackageManager.NameNotFoundException e) {
                        e.printStackTrace();
                    }

                    pb_bar.setProgress(index);
                    Log.i("进度index = = ：",String.valueOf(index));

                    Message message = Message.obtain();
                    message.what = SCANNING_CACHE;
                    message.obj = name;
                    Log.i("包名 Name = = ：",name);
                    mHandler.sendMessage(message);

                    try {
                        Thread.sleep(200);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                //循环结束
                Message message = Message.obtain();
                message.what = SCANNING_FINISH;
                Log.i("循环结束：","扫描完毕");
                mHandler.sendMessage(message);
            }
        }.start();
//        Message message = Message.obtain();
//        message.what = ONE_KEY_CLEAR;
//        mHandler.sendMessage(message);
    }

    /***
     * 通过包名获取该缓存：有的有缓存
     *                     有的没缓存
     * @param packageName 包名
     *
     */
    private void getPackageCache(String packageName) {

        IPackageStatsObserver.Stub mObserver = new IPackageStatsObserver.Stub(){

            public void onGetStatsCompleted(PackageStats stats, boolean success){

                //缓存大小过程，在子线程中不能去更新UI
                // byte类型的值转换成字符串
                long cacheSize = stats.cacheSize;
                //有缓存，更新UI
                if(cacheSize > 0){
                    //通知主线程更新UI
                    Message message = Message.obtain();
                    message.what = UPDATE_LIST_VIEW;
                    //维护相应的Bean数据
                    CacheInfo cacheInfo = new CacheInfo();
                    cacheInfo.packageName = stats.packageName;
                    cacheInfo.cacheSize = stats.cacheSize;
                    try {
                        cacheInfo.apkName = manager.getApplicationInfo(stats.packageName,0)
                                .loadLabel(manager).toString();
                        cacheInfo.icon = manager.getApplicationInfo(stats.packageName,0)
                                .loadIcon(manager);
                    } catch (PackageManager.NameNotFoundException e) {
                        e.printStackTrace();
                    }
                    //获取缓存
                    message.obj = cacheInfo;
                    Log.i("缓存应用程序名====== ",cacheInfo.apkName);
                    Log.i("缓存应用包名====== ",cacheInfo.packageName);
                    Log.i("缓存大小====== ", Formatter.formatFileSize(
                            getApplicationContext(), cacheInfo.cacheSize));
                    mHandler.sendMessage(message);
                }
            }
        };

        //String str = android.text.format.Formatter.
        //formatFileSize(getApplicationContext(),stats.cacheSize);
        //Log.d("缓存大小：= ",str);
        /***
         * 获取mObserver对象，调用onGetStatsCompleted（）获取缓存大小
         * "com.android.browser",包名
         *  mObserver  aidl指向类的对象
         *
         *   PackageManager.getPackageSizeInfo("com.android.browser",mObserver);
         *   系统隐藏方法，不能直接调用，采用反射的方法
         *
         *///manager.getPackageSizeInfo("com.android.browser",mObserver);
        /***
         * 反射   1 获取指定类的字节码文件
         */
        try {
            Class<?> mClass = Class.forName("android.content.pm.PackageManager");
            /***
             *  2 拿到方法去调用
             *  "getPackageSizeInfo",  调用的函数名
             *   String.class  manager.getPackageSizeInfo("com.android.browser",mObserver);
             *   中第一个传入参数的类型
             */
            Method method = mClass.getMethod("getPackageSizeInfo",
                    String.class, IPackageStatsObserver.class);
            /***
             * 3 获取对象调用方法
             *  manager, 包资源管理对象
             * "com.android.browser",  应用报名
             * mObserver   aidl文件对象
             */
            method.invoke(manager,packageName,mObserver);

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }

    }

}
