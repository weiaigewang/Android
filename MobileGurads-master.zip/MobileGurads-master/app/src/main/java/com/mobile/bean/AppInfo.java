package com.mobile.bean;

import android.graphics.drawable.Drawable;

/**
 *
 * Created by xiaofei on 2017/4/2.
 */

public class AppInfo {

    //应用程序标签
    public String appLabel;
    //应用程序图像
    public Drawable appIcon ;
    //应用程序所对应的包名
    public String appPackageName ;

    public boolean isSdCard;

    public boolean isSystem;


    public String getAppLabel() {
        return appLabel;
    }

    public void setAppLabel(String appLabel) {
        this.appLabel = appLabel;
    }

    public Drawable getAppIcon() {
        return appIcon;
    }

    public void setAppIcon(Drawable appIcon) {
        this.appIcon = appIcon;
    }

    public boolean isSdCard() {
        return isSdCard;
    }

    public void setSdCard(boolean sdCard) {
        isSdCard = sdCard;
    }

    public boolean isSystem() {
        return isSystem;
    }

    public void setSystem(boolean system) {
        isSystem = system;
    }

    public String getAppPackageName() {
        return appPackageName;
    }

    public void setAppPackageName(String appPackageName) {
        this.appPackageName = appPackageName;
    }
}
