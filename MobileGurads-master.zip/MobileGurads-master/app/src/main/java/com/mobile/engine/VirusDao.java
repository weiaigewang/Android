package com.mobile.engine;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

/**
 * 获取病毒库中的app签名的md5加密码
 * Created by xiaofei on 2017/3/13.
 *
 */

public class VirusDao {

    private static String path = "data/data/com.mobile.guards/files/virus.db";
    private static List<String> list;

    /*****
     * 获取数据库中所有的病毒apk的签名md5码
     * @return
     */
    public static List<String> getVirusList(){

        SQLiteDatabase db = SQLiteDatabase.openDatabase(path,null,SQLiteDatabase.OPEN_READONLY);
        Cursor cursor = db.query("datable",
                new String[]{"md5"},null,null,null,null,null);
        list = new ArrayList<String>();
        while (cursor.moveToNext()){
           list.add(cursor.getString(0));
        }
        cursor.close();
        db.close();
        return list;
    }

}
