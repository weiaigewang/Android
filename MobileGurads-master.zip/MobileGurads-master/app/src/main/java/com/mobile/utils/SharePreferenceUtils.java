package com.mobile.utils;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Created by xiaofei on 2017/3/2.
 * 存储设置的选项
 */

public class SharePreferenceUtils {

    private static SharedPreferences share;
    //写数据
    public static void putUpdateOrNot(Context context,String key,boolean isUpdate){
        if(share == null){
            share = context.getSharedPreferences("config",context.MODE_PRIVATE);
        }


    }
}
