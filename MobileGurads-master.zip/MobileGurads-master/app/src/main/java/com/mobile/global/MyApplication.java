package com.mobile.global;

import android.app.Application;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

/**
 * Created by xiaofei on 2017/3/14.
 *
 */

public class MyApplication extends Application{

    private static final String tag = "MyApplication";
    @Override
    public void onCreate() {
        super.onCreate();
        /****
         * 不活任意模块的异常
         */
      Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
          @Override
          public void uncaughtException(Thread t, Throwable e) {
              //获取到未捕获的异常
              e.printStackTrace();
              Log.e(tag,"捕获到程序的应用异常");

              //将捕获的异常存储到SD卡中
              String path = Environment.getExternalStorageDirectory()
                      .getAbsoluteFile()+ File.separator+"error.log";
              try {
                  PrintWriter writer = new PrintWriter(path);
                  e.printStackTrace(writer);

              } catch (FileNotFoundException e1) {
                  e1.printStackTrace();
              }
              //上传到公司的服务器中

              //退出现在的应用
              //System.exit(0);
          }
      });
    }
}
