package com.mobile.utils;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * Created by xiaofei on 2017/2/27.
 *
 */
public class StreamUtil {

    /**
     *
     * @param is:流对象
     * @return  :返回的字符串
     */
    public static String streamToString(InputStream is) {
        /*****
         * 读取流的时候，将读取内容进行存入缓存中，然后一次性转换成字符串
         * 返回
         */
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        //读取流操作
        byte[] buffer = new byte[1024];
        int tmp = -1;
        try {
            while((tmp = is.read(buffer))!= -1){
                /***
                 * 读取的内容写入ByteArrayOutputStream中
                 */
                baos.write(buffer,0,tmp);
            }//返回字符串
            return baos.toString();
        } catch (IOException e) {
            e.printStackTrace();
        }finally{
            try {
                baos.close();
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
        return null;
    }
}
