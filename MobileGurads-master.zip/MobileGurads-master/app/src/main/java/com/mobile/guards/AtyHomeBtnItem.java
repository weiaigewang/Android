package com.mobile.guards;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Created by xiaofei on 2017/3/17.
 *
 */

public class AtyHomeBtnItem extends LinearLayout {

    private static final String NAME_SPACE = "http://schemas.android.com/apk/res/com.mobile.guards";

    public static ImageView imageView;
    private static View view;
    private String mItemText;
    private int mImg;

    public AtyHomeBtnItem(Context context) {
        this(context,null);
    }

    public AtyHomeBtnItem(Context context, AttributeSet attrs) {
        this(context, attrs,0);
    }

    public AtyHomeBtnItem(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

        /***将设置界面的一个条目转换成View对象，
         * 直接添加到AtyHomeBtnItem中对应的view
         * ***/
        View.inflate(context,R.layout.aty_home_item,this);
        //以一种加载布局的方法

        //view =  View.inflate(context,R.layout.aty_home_item,this);
        //imageView = (ImageView) view.findViewById(R.id.id_iv_clear_virus_img);
        TextView textView = (TextView)findViewById(R.id.id_tv_clear_cache);
        ImageView imageView = (ImageView) findViewById(R.id.id_iv_clear_virus_img);
        //this.addView(view);

        //通过命名空间+属性名称获取属性值
        mItemText = attrs.getAttributeValue(NAME_SPACE,"text");
        mImg = attrs.getAttributeResourceValue(NAME_SPACE,"src",0);

        //设置条目名称
        imageView.setImageResource(mImg);
        textView.setText(mItemText);
    }

}
