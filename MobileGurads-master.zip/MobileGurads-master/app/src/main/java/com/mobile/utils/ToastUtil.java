package com.mobile.utils;

import android.content.Context;
import android.widget.Toast;

/**
 * Created by xiaofei on 2017/2/28.
 */

public class ToastUtil {

    //打印土司
    public static void show(Context context,String message){
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
    }
}
