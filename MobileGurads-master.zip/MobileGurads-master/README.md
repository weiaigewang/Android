# MobileGurads

##请参看项目中的管家.doc文件说明。这是一个简单的安全软件。
