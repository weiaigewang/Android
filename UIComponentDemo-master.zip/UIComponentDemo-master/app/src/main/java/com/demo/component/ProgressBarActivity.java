package com.demo.component;

import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.ProgressBar;

public class ProgressBarActivity extends AppCompatActivity {

    private ProgressBar mProgress;
    private int mProgressStatus = 0;

    private int[] data = new int[100];
    int hasData = 0;

    private Handler mHandler = new Handler();
    @Override
    protected void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        setContentView(R.layout.activity_progrecc_bar);

        mProgress = (ProgressBar) findViewById(R.id.progress_bar);
        initView();
    }

    private void initView() {
        // Start lengthy operation in a background thread
        new Thread(new Runnable() {

            public void run() {
                while (mProgressStatus < 100) {
                    mProgressStatus = doWork();

                    // Update the progress bar
                    mHandler.post(new Runnable() {
                        public void run() {
                            mProgress.setProgress(mProgressStatus);
                        }
                    });
                }
            }
        }).start();
    }

    private int doWork() {


        data[hasData++] = (int) (Math.random() * 100);
        try {
            Thread.sleep(100);
        }
        catch (InterruptedException e) {
            e.printStackTrace();
        }
        Log.i("hasData = ",String.valueOf(hasData));
        return hasData;
    }

}
