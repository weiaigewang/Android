package com.demo.utils;

import android.content.Context;
import android.widget.Toast;

/**
 *
 * Created by xiaofei on 2017/4/12.
 */

public class ToastUtils {

    public static void ToastProvider(Context context,String str){

        Toast.makeText(context, str, Toast.LENGTH_SHORT).show();
    }
}
