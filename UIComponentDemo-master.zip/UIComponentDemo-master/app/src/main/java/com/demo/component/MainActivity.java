package com.demo.component;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button btnListView,btnDialog,btnMenu,btnContextMenu,btnProcess;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initView();
        initData();
    }

    private void initView() {
        btnListView = (Button) findViewById(R.id.id_lv_show);
        btnDialog = (Button) findViewById(R.id.id_dialog_show);
        btnMenu = (Button) findViewById(R.id.id_menu_show);
        btnContextMenu = (Button) findViewById(R.id.id_context_menu);
        btnProcess = (Button) findViewById(R.id.id_progress);
    }

    private void initData() {
        btnDialog.setOnClickListener(new ButtonEvent());
        btnListView.setOnClickListener(new ButtonEvent());
        btnMenu.setOnClickListener(new ButtonEvent());
        btnContextMenu.setOnClickListener(new ButtonEvent());
        btnProcess.setOnClickListener(new ButtonEvent());
    }

    public class ButtonEvent implements View.OnClickListener {

        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.id_lv_show:
                    Intent intent = new Intent(MainActivity.this,ListViewActivity.class);
                    startActivity(intent);
                    break;
                case R.id.id_dialog_show:
                    //Intent intent2 = new Intent(MainActivity.this,DialogActivity.class);
                    //startActivity(intent2);
                    showDialog();
                    break;
                case R.id.id_menu_show:
                    Intent intent3 = new Intent(MainActivity.this,MenuActivity.class);
                    startActivity(intent3);
                    break;
                case R.id.id_context_menu:
                    Intent intent4 = new Intent(MainActivity.this,ContextMenuActivity.class);
                    startActivity(intent4);
                    break;
                case R.id.id_progress:
                    Intent intent5 = new Intent(MainActivity.this,ProgressBarActivity.class);
                    startActivity(intent5);
                    break;
            }

        }
    }

    private void showDialog() {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        LayoutInflater inflater = getLayoutInflater();


        builder.setView(inflater.inflate(R.layout.dialog_custom, null))
                // Add action buttons
                .setPositiveButton("Sing In", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        // sign in the user ...
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        //LoginDialogFragment.this.getDialog().cancel();
                    }
                });
        builder.create();
        builder.show();

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }


}
