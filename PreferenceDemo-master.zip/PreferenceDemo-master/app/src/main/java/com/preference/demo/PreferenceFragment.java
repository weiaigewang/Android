package com.preference.demo;

import android.os.Bundle;
import android.support.annotation.Nullable;

/**
 *
 * Created by xiaofei on 2017/4/13.
 */

public class PreferenceFragment extends android.preference.PreferenceFragment {

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        addPreferencesFromResource(R.xml.preference);
    }
}
