# NotePad
This is an AndroidStudio rebuild of google SDK sample NotePad
## 1 修改了项目的主题，更改了图标和布局资源。
## 2 完成时间添加
## 3 完成了搜索功能

#### 实现效果图在项目中有传上去四张图片
<img width="300" height="500"  src="https://github.com/weiaigewang/NotePad-master/blob/master/Screenshot_2017-06-12-11-34-14.png"></br>
<img width="300" height="500"  src="https://github.com/weiaigewang/NotePad-master/blob/master/Screenshot_2017-06-12-11-34-18.png"></br>
<img width="300" height="500"  src="https://github.com/weiaigewang/NotePad-master/blob/master/Screenshot_2017-06-12-11-34-34.png"></br>
<img width="300" height="500"  src="https://github.com/weiaigewang/NotePad-master/blob/master/Screenshot_2017-06-12-11-34-45.png"></br>
